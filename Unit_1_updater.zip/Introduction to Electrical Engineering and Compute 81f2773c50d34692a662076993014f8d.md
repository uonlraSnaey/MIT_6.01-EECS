# Introduction to Electrical Engineering and Computer Science

[Class Website](https://ocw.mit.edu/courses/6-01sc-introduction-to-electrical-engineering-and-computer-science-i-spring-2011/)

[6.01 课程书籍（Note），2011 年春季 (PDF)](https://ocw.mit.edu/courses/6-01sc-introduction-to-electrical-engineering-and-computer-science-i-spring-2011/resources/mit6_01scs11_textbook/)

[中文视频资源](https://www.bilibili.com/video/av84551129/?vd_source=502f853866afa6a1485718aa0ae3ab81)

[Unit 1: software Engineering](Introduction%20to%20Electrical%20Engineering%20and%20Compute%2081f2773c50d34692a662076993014f8d/Unit%201%20software%20Engineering%206f3e269fa1ed44ef9082b748e8ed6931.md)