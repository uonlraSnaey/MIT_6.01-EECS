# Unit 1: software Engineering

Owner: Kasen Jones

本单元重点介绍抽象和模块化对管理复杂性管理的重要性。

一般原则是在状态机的背景下发展起来的，在控制移动机器人的行为方面有实际的应用。

![Untitled](Unit%201%20software%20Engineering%206f3e269fa1ed44ef9082b748e8ed6931/Untitled.png)

---

主题：

procedures， data structure, objects, state machines

---

抽象和模块化（Modularity）

Combinators

Cascade: make new state machine (SM) by cascading two SMs

Parallel: make new SM by running two SMs in parallel

Select: combine two inputs to get one output

---

[OPP](Unit%201%20software%20Engineering%206f3e269fa1ed44ef9082b748e8ed6931/OPP%204afe672140744fca83853cc411403389.md)

[State Machines](Unit%201%20software%20Engineering%206f3e269fa1ed44ef9082b748e8ed6931/State%20Machines%20f468c14824f744a6b8349519bc949915.md)